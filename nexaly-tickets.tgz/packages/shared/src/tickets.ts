import { z } from "zod";

const snowflake = z.string().regex(/^\d{17,20}$/);

export const ticketSettingsSchema = z
  .object({
    enabled: z.boolean(),
    panelChannelId: snowflake.nullable(),
    categoryId: snowflake.nullable(),
    staffRoleId: snowflake.nullable(),
    logChannelId: snowflake.nullable(),
    panelTitle: z.string().trim().min(1).max(80),
    panelText: z.string().trim().min(1).max(1000),
    openMessage: z.string().trim().min(1).max(1000),
  })
  .strict();

export type TicketSettingsInput = z.infer<typeof ticketSettingsSchema>;
