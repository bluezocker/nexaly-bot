import { ApiBanner } from "@/lib/api-banner";
import { apiFetchSafe } from "@/lib/api";
import { StreamsForm } from "./streams-form";

export const dynamic = "force-dynamic";

type Payload = {
  subscriptions: {
    id: string;
    platform: string;
    channelKey: string;
    displayName: string;
    announceChannelId: string;
    enabled: boolean;
  }[];
  providers: Record<string, boolean>;
};

export default async function StreamsPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const [data, channels] = await Promise.all([
    apiFetchSafe<Payload>(`/v1/guilds/${guildId}/streams`, { subscriptions: [], providers: {} }),
    apiFetchSafe<{ channels: { id: string; name: string }[] }>(`/v1/guilds/${guildId}/channels`, {
      channels: [],
    }),
  ]);
  return (
    <div>
      <ApiBanner error={data.error ?? channels.error} />
      <StreamsForm
        guildId={guildId}
        subscriptions={data.data.subscriptions ?? []}
        providers={data.data.providers ?? {}}
        channels={channels.data.channels ?? []}
      />
    </div>
  );
}
