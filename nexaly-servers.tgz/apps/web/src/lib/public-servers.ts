import { API_URL } from "./config";

export type PublicServer = {
  name: string;
  iconUrl: string | null;
  memberCount: number | null;
};

export async function loadPublicServers(): Promise<{ count: number; servers: PublicServer[] }> {
  try {
    const response = await fetch(`${API_URL}/v1/public/servers`, { next: { revalidate: 60 } });
    if (!response.ok) return { count: 0, servers: [] };
    const json = (await response.json()) as { count?: number; servers?: PublicServer[] };
    return { count: json.count ?? json.servers?.length ?? 0, servers: json.servers ?? [] };
  } catch {
    return { count: 0, servers: [] };
  }
}
