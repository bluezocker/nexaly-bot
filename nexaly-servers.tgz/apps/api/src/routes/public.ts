import type { FastifyInstance } from "fastify";
import type { AppDeps } from "../app.js";

function iconUrl(guildId: string, icon: string | null): string | null {
  if (!icon) return null;
  const ext = icon.startsWith("a_") ? "gif" : "png";
  return `https://cdn.discordapp.com/icons/${guildId}/${icon}.${ext}?size=128`;
}

export async function registerPublicRoutes(app: FastifyInstance, deps: AppDeps): Promise<void> {
  app.get("/v1/public/servers", async () => {
    const cacheKey = "public:servers";
    const cached = await deps.redis.get(cacheKey);
    if (cached) return JSON.parse(cached) as unknown;

    const where = { botJoinedAt: { not: null } };
    const [count, rows] = await Promise.all([
      deps.prisma.guild.count({ where }),
      deps.prisma.guild.findMany({
        where,
        select: { id: true, name: true, icon: true, memberCount: true },
        orderBy: [{ memberCount: { sort: "desc", nulls: "last" } }, { name: "asc" }],
        take: 200,
      }),
    ]);

    const payload = {
      count,
      servers: rows.map((row) => ({
        name: row.name,
        iconUrl: iconUrl(row.id, row.icon),
        memberCount: row.memberCount,
      })),
    };
    await deps.redis.set(cacheKey, JSON.stringify(payload), "EX", 60);
    return payload;
  });
}
