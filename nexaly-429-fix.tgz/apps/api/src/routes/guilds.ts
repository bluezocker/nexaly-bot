import { notFound } from "@nexaly/shared";
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import type { AppDeps } from "../app.js";
import { requireDiscordToken, requireUser } from "../app.js";
import { fetchCurrentUserGuilds } from "../services/discord-oauth.js";
import { ensureGuildAccess, listManageableGuilds } from "../services/guilds.js";

const guildParams = z.object({ guildId: z.string().regex(/^\d{17,20}$/) });

export async function registerGuildRoutes(app: FastifyInstance, deps: AppDeps): Promise<void> {
  app.get("/v1/guilds", async (request) => {
    const { userId, sessionId } = await requireUser(request);
    const accessToken = await requireDiscordToken(deps.redis, sessionId);
    const oauthGuilds = await fetchCurrentUserGuilds(deps.redis, userId, accessToken);
    const guilds = await listManageableGuilds({
      prisma: deps.prisma,
      userId,
      oauthGuilds,
      clientId: deps.env.DISCORD_CLIENT_ID,
    });
    return { guilds };
  });

  app.get("/v1/guilds/:guildId", async (request) => {
    const { userId, sessionId } = await requireUser(request);
    const params = guildParams.parse(request.params);
    const accessToken = await requireDiscordToken(deps.redis, sessionId);
    const oauthGuilds = await fetchCurrentUserGuilds(deps.redis, userId, accessToken);
    await ensureGuildAccess({
      prisma: deps.prisma,
      userId,
      guildId: params.guildId,
      oauthGuilds,
    });
    const guild = await deps.prisma.guild.findUnique({
      where: { id: params.guildId },
      include: { settings: true, modules: true },
    });
    if (!guild) throw notFound("Bot is not installed on this server yet");
    return {
      id: guild.id,
      name: guild.name,
      icon: guild.icon,
      ownerId: guild.ownerId,
      memberCount: guild.memberCount,
      botJoinedAt: guild.botJoinedAt,
      settings: guild.settings,
      modules: guild.modules,
    };
  });
}
