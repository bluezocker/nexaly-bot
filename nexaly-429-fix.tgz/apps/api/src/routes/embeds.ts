import {
  embedSendSchema,
  embedTemplateSchema,
  notFound,
  toDiscordEmbed,
  validationError,
} from "@nexaly/shared";
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import type { AppDeps } from "../app.js";
import { requireDiscordToken, requireUser } from "../app.js";
import { fetchGuildChannels, sendChannelMessage, TEXT_CHANNEL_TYPES } from "../services/discord-bot-rest.js";
import { fetchCurrentUserGuilds } from "../services/discord-oauth.js";
import { ensureGuildAccess } from "../services/guilds.js";

const guildParams = z.object({ guildId: z.string().regex(/^\d{17,20}$/) });
const templateParams = guildParams.extend({ templateId: z.string().min(1) });

async function authorize(deps: AppDeps, request: Parameters<typeof requireUser>[0], guildId: string) {
  const { userId, sessionId } = await requireUser(request);
  const accessToken = await requireDiscordToken(deps.redis, sessionId);
  const oauthGuilds = await fetchCurrentUserGuilds(deps.redis, userId, accessToken);
  await ensureGuildAccess({ prisma: deps.prisma, userId, guildId, oauthGuilds });
  return { userId };
}

export async function registerEmbedRoutes(app: FastifyInstance, deps: AppDeps): Promise<void> {
  app.get("/v1/guilds/:guildId/embeds", async (request) => {
    const params = guildParams.parse(request.params);
    await authorize(deps, request, params.guildId);
    const templates = await deps.prisma.embedTemplate.findMany({
      where: { guildId: params.guildId },
      orderBy: { updatedAt: "desc" },
    });
    return { templates };
  });

  app.post("/v1/guilds/:guildId/embeds", async (request) => {
    const params = guildParams.parse(request.params);
    const { userId } = await authorize(deps, request, params.guildId);
    const parsed = embedTemplateSchema.safeParse(request.body);
    if (!parsed.success) throw validationError("Invalid embed", parsed.error.issues);
    const template = await deps.prisma.embedTemplate.create({
      data: {
        guildId: params.guildId,
        name: parsed.data.name,
        content: parsed.data.content,
        embed: parsed.data.embed,
        updatedBy: userId,
      },
    });
    return { template };
  });

  app.put("/v1/guilds/:guildId/embeds/:templateId", async (request) => {
    const params = templateParams.parse(request.params);
    const { userId } = await authorize(deps, request, params.guildId);
    const parsed = embedTemplateSchema.safeParse(request.body);
    if (!parsed.success) throw validationError("Invalid embed", parsed.error.issues);
    const updated = await deps.prisma.embedTemplate.updateMany({
      where: { id: params.templateId, guildId: params.guildId },
      data: {
        name: parsed.data.name,
        content: parsed.data.content,
        embed: parsed.data.embed,
        updatedBy: userId,
      },
    });
    if (!updated.count) throw notFound("Template not found");
    return { ok: true };
  });

  app.delete("/v1/guilds/:guildId/embeds/:templateId", async (request) => {
    const params = templateParams.parse(request.params);
    await authorize(deps, request, params.guildId);
    const deleted = await deps.prisma.embedTemplate.deleteMany({
      where: { id: params.templateId, guildId: params.guildId },
    });
    if (!deleted.count) throw notFound("Template not found");
    return { ok: true };
  });

  app.post("/v1/guilds/:guildId/embeds/send", async (request) => {
    const params = guildParams.parse(request.params);
    await authorize(deps, request, params.guildId);
    const parsed = embedSendSchema.safeParse(request.body);
    if (!parsed.success) throw validationError("Invalid send payload", parsed.error.issues);
    if (!deps.env.DISCORD_TOKEN) throw validationError("Bot token missing on API");

    const channels = await fetchGuildChannels(deps.env.DISCORD_TOKEN, params.guildId);
    const target = channels.find((channel) => channel.id === parsed.data.channelId);
    if (!target || !TEXT_CHANNEL_TYPES.has(target.type)) {
      throw validationError("Channel is not a text channel of this guild");
    }

    let embed = parsed.data.embed;
    let content = parsed.data.content;
    if (parsed.data.templateId) {
      const template = await deps.prisma.embedTemplate.findFirst({
        where: { id: parsed.data.templateId, guildId: params.guildId },
      });
      if (!template) throw notFound("Template not found");
      embed = template.embed as typeof embed;
      content = content ?? template.content ?? undefined;
    }
    if (!embed) throw validationError("Embed missing");

    await sendChannelMessage(deps.env.DISCORD_TOKEN, parsed.data.channelId, {
      content,
      embeds: [toDiscordEmbed(embed)],
    });
    return { ok: true };
  });
}
