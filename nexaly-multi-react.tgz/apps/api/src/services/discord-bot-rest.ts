import { DISCORD_API_BASE } from "@nexaly/shared";

export interface DiscordChannel {
  id: string;
  name: string;
  type: number;
  parent_id?: string | null;
}

export async function fetchGuildChannels(
  botToken: string,
  guildId: string,
): Promise<DiscordChannel[]> {
  const response = await fetch(`${DISCORD_API_BASE}/guilds/${guildId}/channels`, {
    headers: { Authorization: `Bot ${botToken}` },
  });
  if (!response.ok) {
    throw Object.assign(new Error(`Failed to list channels (${response.status})`), {
      statusCode: response.status === 403 ? 403 : 502,
    });
  }
  return (await response.json()) as DiscordChannel[];
}

export const TEXT_CHANNEL_TYPES = new Set([0, 5]);

export interface DiscordRole {
  id: string;
  name: string;
  color: number;
  managed: boolean;
  position: number;
  permissions: string;
}

export async function fetchGuildRoles(botToken: string, guildId: string): Promise<DiscordRole[]> {
  const response = await fetch(`${DISCORD_API_BASE}/guilds/${guildId}/roles`, {
    headers: { Authorization: `Bot ${botToken}` },
  });
  if (!response.ok) {
    throw Object.assign(new Error(`Failed to list roles (${response.status})`), {
      statusCode: response.status === 403 ? 403 : 502,
    });
  }
  return (await response.json()) as DiscordRole[];
}


export async function sendChannelMessage(
  botToken: string,
  channelId: string,
  body: { content?: string; embeds?: Record<string, unknown>[] },
): Promise<string> {
  const response = await fetch(`${DISCORD_API_BASE}/channels/${channelId}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Bot ${botToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    throw Object.assign(new Error(`Failed to send message (${response.status})`), {
      statusCode: response.status === 403 ? 403 : 502,
    });
  }
  const json = (await response.json()) as { id: string };
  return json.id;
}

export async function fetchChannelMessage(
  botToken: string,
  channelId: string,
  messageId: string,
): Promise<{ id: string } | null> {
  const response = await fetch(`${DISCORD_API_BASE}/channels/${channelId}/messages/${messageId}`, {
    headers: { Authorization: `Bot ${botToken}` },
  });
  if (response.status === 404) return null;
  if (!response.ok) {
    throw Object.assign(new Error(`Failed to read message (${response.status})`), {
      statusCode: response.status === 403 ? 403 : 502,
    });
  }
  return (await response.json()) as { id: string };
}

export async function sendChannelComponents(
  botToken: string,
  channelId: string,
  body: { content?: string; embeds?: Record<string, unknown>[]; components?: unknown[] },
): Promise<string> {
  const response = await fetch(`${DISCORD_API_BASE}/channels/${channelId}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Bot ${botToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    throw Object.assign(new Error(`Failed to send message (${response.status})`), {
      statusCode: response.status === 403 ? 403 : 502,
    });
  }
  const json = (await response.json()) as { id: string };
  return json.id;
}

export async function addBotReaction(
  botToken: string,
  channelId: string,
  messageId: string,
  emoji: string,
): Promise<void> {
  const encoded = encodeURIComponent(emoji);
  const url = `${DISCORD_API_BASE}/channels/${channelId}/messages/${messageId}/reactions/${encoded}/@me`;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const response = await fetch(url, { method: "PUT", headers: { Authorization: `Bot ${botToken}` } });
    if (response.ok || response.status === 204) return;
    if (response.status === 429 && attempt < 3) {
      const body = (await response.json().catch(() => null)) as { retry_after?: number } | null;
      const wait = Math.min(5000, Math.ceil((body?.retry_after ?? 1) * 1000));
      await new Promise((resolve) => setTimeout(resolve, wait));
      continue;
    }
    throw Object.assign(new Error(`Failed to add reaction (${response.status})`), {
      statusCode: response.status === 403 ? 403 : 502,
    });
  }
}
