"use client";

import { useState } from "react";

type Embed = {
  title?: string;
  description?: string;
  color?: number;
  footer?: string;
  author?: string;
  image?: string;
  thumbnail?: string;
  fields: { name: string; value: string; inline?: boolean }[];
};

type Template = { id: string; name: string; content: string | null; embed: Embed };

const emptyEmbed: Embed = { title: "Nexaly", description: "Neue Nachricht", color: 0x7c5cff, fields: [] };

export function EmbedBuilder(props: {
  guildId: string;
  templates: Template[];
  channels: { id: string; name: string }[];
}) {
  const [templates, setTemplates] = useState(props.templates);
  const [name, setName] = useState("Ankündigung");
  const [content, setContent] = useState("");
  const [embed, setEmbed] = useState<Embed>(emptyEmbed);
  const [selected, setSelected] = useState<string | null>(null);
  const [channelId, setChannelId] = useState(props.channels[0]?.id ?? "");
  const [status, setStatus] = useState<string | null>(null);

  function patch(partial: Partial<Embed>) {
    setEmbed((current) => ({ ...current, ...partial }));
  }

  async function save() {
    const body = { name, content, embed };
    const url = selected
      ? `/api/guilds/${props.guildId}/embeds/${selected}`
      : `/api/guilds/${props.guildId}/embeds`;
    const response = await fetch(url, {
      method: selected ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!response.ok) {
      setStatus("Speichern fehlgeschlagen — Limits prüfen");
      return;
    }
    if (!selected) {
      const payload = (await response.json()) as { template: Template };
      setTemplates((current) => [payload.template, ...current]);
      setSelected(payload.template.id);
    }
    setStatus("Gespeichert");
  }

  async function send() {
    const response = await fetch(`/api/guilds/${props.guildId}/embeds/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ channelId, templateId: selected ?? undefined, content, embed }),
    });
    setStatus(response.ok ? "Gesendet" : "Senden fehlgeschlagen");
  }

  async function remove(id: string) {
    await fetch(`/api/guilds/${props.guildId}/embeds/${id}`, { method: "DELETE" });
    setTemplates((current) => current.filter((item) => item.id !== id));
    if (selected === id) setSelected(null);
  }

  const colorHex = `#${(embed.color ?? 0x7c5cff).toString(16).padStart(6, "0")}`;

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
      <div className="space-y-4">
        <section className="rounded-2xl border border-nx-border bg-nx-card p-5">
          <h2 className="text-lg font-semibold">Embed-Builder</h2>
          <p className="mt-1 text-sm text-nx-muted">Discord-Limits: Titel 256, Beschreibung 4096, 25 Felder.</p>
          <div className="mt-4 grid gap-3">
            <input className="rounded-lg border border-nx-border bg-nx-elevated px-3 py-2 text-sm" value={name} onChange={(e) => setName(e.target.value)} placeholder="Vorlagenname" />
            <input className="rounded-lg border border-nx-border bg-nx-elevated px-3 py-2 text-sm" value={content} onChange={(e) => setContent(e.target.value)} placeholder="Nachrichtentext über dem Embed" />
            <input className="rounded-lg border border-nx-border bg-nx-elevated px-3 py-2 text-sm" value={embed.title ?? ""} onChange={(e) => patch({ title: e.target.value })} placeholder="Titel" />
            <textarea className="rounded-lg border border-nx-border bg-nx-elevated px-3 py-2 text-sm" rows={4} value={embed.description ?? ""} onChange={(e) => patch({ description: e.target.value })} placeholder="Beschreibung" />
            <label className="text-sm text-nx-muted">
              Farbe
              <input
                type="color"
                className="ml-2"
                value={colorHex}
                onChange={(e) => patch({ color: parseInt(e.target.value.slice(1), 16) })}
              />
            </label>
            <input className="rounded-lg border border-nx-border bg-nx-elevated px-3 py-2 text-sm" value={embed.footer ?? ""} onChange={(e) => patch({ footer: e.target.value })} placeholder="Footer" />
            <input className="rounded-lg border border-nx-border bg-nx-elevated px-3 py-2 text-sm" value={embed.image ?? ""} onChange={(e) => patch({ image: e.target.value })} placeholder="Bild-URL" />
          </div>
          <button
            type="button"
            className="mt-3 text-sm text-nx-accent"
            onClick={() => patch({ fields: [...embed.fields, { name: "Feld", value: "Wert" }] })}
          >
            Feld hinzufügen
          </button>
          <ul className="mt-2 space-y-2">
            {embed.fields.map((field, index) => (
              <li key={index} className="grid gap-2 sm:grid-cols-2">
                <input className="rounded-lg border border-nx-border bg-nx-elevated px-3 py-2 text-sm" value={field.name} onChange={(e) => {
                  const fields = [...embed.fields];
                  fields[index] = { ...field, name: e.target.value };
                  patch({ fields });
                }} />
                <input className="rounded-lg border border-nx-border bg-nx-elevated px-3 py-2 text-sm" value={field.value} onChange={(e) => {
                  const fields = [...embed.fields];
                  fields[index] = { ...field, value: e.target.value };
                  patch({ fields });
                }} />
              </li>
            ))}
          </ul>
        </section>

        <div className="flex flex-wrap gap-3">
          <select className="rounded-lg border border-nx-border bg-nx-elevated px-3 py-2 text-sm" value={channelId} onChange={(e) => setChannelId(e.target.value)}>
            {props.channels.map((channel) => (
              <option key={channel.id} value={channel.id}>#{channel.name}</option>
            ))}
          </select>
          <button type="button" onClick={() => void save()} className="rounded-xl bg-nx-accent px-4 py-2 text-sm font-semibold">Speichern</button>
          <button type="button" onClick={() => void send()} className="rounded-xl border border-nx-border px-4 py-2 text-sm">Senden</button>
          <span className="text-sm text-nx-muted">{status}</span>
        </div>
      </div>

      <aside className="space-y-4">
        <div className="rounded-2xl border border-nx-border bg-nx-card p-4">
          <p className="text-xs uppercase text-nx-muted">Vorschau</p>
          <div className="mt-3 overflow-hidden rounded-xl border border-nx-border" style={{ borderLeft: `4px solid ${colorHex}` }}>
            <div className="bg-nx-elevated p-4">
              <p className="font-semibold">{embed.title}</p>
              <p className="mt-1 whitespace-pre-wrap text-sm text-nx-muted">{embed.description}</p>
              {embed.fields.map((field, index) => (
                <p key={index} className="mt-2 text-sm"><strong>{field.name}</strong><br />{field.value}</p>
              ))}
              {embed.footer ? <p className="mt-3 text-xs text-nx-muted">{embed.footer}</p> : null}
            </div>
          </div>
        </div>
        <div className="rounded-2xl border border-nx-border bg-nx-card p-4">
          <p className="text-xs uppercase text-nx-muted">Vorlagen</p>
          <ul className="mt-2 space-y-2 text-sm">
            {templates.map((template) => (
              <li key={template.id} className="flex justify-between gap-2">
                <button
                  type="button"
                  className="text-left"
                  onClick={() => {
                    setSelected(template.id);
                    setName(template.name);
                    setContent(template.content ?? "");
                    setEmbed({ ...template.embed, fields: template.embed.fields ?? [] });
                  }}
                >
                  {template.name}
                </button>
                <button type="button" className="text-red-300" onClick={() => void remove(template.id)}>×</button>
              </li>
            ))}
          </ul>
        </div>
      </aside>
    </div>
  );
}
