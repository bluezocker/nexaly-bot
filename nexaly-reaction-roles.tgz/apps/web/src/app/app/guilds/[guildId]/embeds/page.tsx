import { apiFetch, apiFetchSafe } from "@/lib/api";
import { EmbedBuilder } from "./embed-builder";

export const dynamic = "force-dynamic";

type Binding = { id: string; channelId: string; messageId: string; emoji: string; roleId: string };
type Role = { id: string; name: string };

export default async function EmbedsPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const [data, channels, settings] = await Promise.all([
    apiFetch<{
      templates: { id: string; name: string; content: string | null; embed: never }[];
      bindings?: Binding[];
    }>(`/v1/guilds/${guildId}/embeds`),
    apiFetch<{ channels: { id: string; name: string }[] }>(`/v1/guilds/${guildId}/channels`).catch(() => ({
      channels: [],
    })),
    apiFetchSafe<{ roles: Role[] }>(`/v1/guilds/${guildId}/settings`, { roles: [] }),
  ]);

  return (
    <EmbedBuilder
      guildId={guildId}
      templates={data.templates as never}
      channels={channels.channels}
      roles={settings.data.roles}
      bindings={data.bindings ?? []}
    />
  );
}
