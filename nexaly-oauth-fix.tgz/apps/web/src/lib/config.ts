export const API_URL = process.env.PUBLIC_API_URL ?? "http://localhost:3001";
export const WEB_URL = process.env.PUBLIC_WEB_URL ?? "https://nexaly.app";
export const SESSION_COOKIE = "nexaly_session";

export function publicPath(path: string): URL {
  return new URL(path, WEB_URL);
}
