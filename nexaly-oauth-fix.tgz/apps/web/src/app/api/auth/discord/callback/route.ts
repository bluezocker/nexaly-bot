import { NextResponse, type NextRequest } from "next/server";
import { API_URL, SESSION_COOKIE, publicPath } from "@/lib/config";

export async function GET(request: NextRequest) {
  const code = request.nextUrl.searchParams.get("code");
  const state = request.nextUrl.searchParams.get("state");
  if (!code || !state) {
    return NextResponse.redirect(publicPath("/login?error=oauth"));
  }
  const apiRes = await fetch(
    `${API_URL}/v1/auth/discord/callback?${new URLSearchParams({ code, state })}`,
    { cache: "no-store" },
  );
  if (!apiRes.ok) return NextResponse.redirect(publicPath("/login?error=oauth"));
  const sessionId = apiRes.headers.get("x-nexaly-session");
  if (!sessionId) return NextResponse.redirect(publicPath("/login?error=session"));
  const redirect = NextResponse.redirect(publicPath("/app"));
  redirect.cookies.set({
    name: SESSION_COOKIE,
    value: sessionId,
    httpOnly: true,
    sameSite: "lax",
    secure: true,
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
  return redirect;
}
